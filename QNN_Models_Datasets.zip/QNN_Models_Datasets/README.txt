Note 1:
The datasets, except for the first one used for training (which is attached here), were downloaded from the references mentioned at the end of the paper, and they are publicly available.
You can access the paper here: https://arxiv.org/abs/2503.07633"

-----------------------------------
Note 2:
I am using Python 3.9.18 and Jupyter Notebook installed via Anaconda.

Please see the attached .txt files, which contain the package versions you may need for compatibility.

Ex:
pennylane                 0.29.1                   pypi_0    pypi
pennylane-lightning       0.30.0                   pypi_0    pypi
pennylane-sf              0.29.1                   pypi_0    pypi

